import React from 'react';
import EmployeeOperations from '../Services/EmployeeOperations';

class ListEmployee extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            employees:[]
        }
    }
    componentDidMount()
    {
        EmployeeOperations.getEmployees().then((res)=>{
            this.setState({employees:res.data});
            console.log(this.state.employees)
        })
    }
    render(){
        return(
            <div>
                <h1 className="text-center">My Details Section</h1>
                <br></br>
                <br></br>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>DateJoined</th>
                                <th>Department</th>
                                <th>Available Leaves</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.employees.map(
                                    emp=>
                                    //console.log(emp)
                                    <tr key={emp.empId}>
                                        <td>{emp.employeeId}</td>
                                        <td>{emp.employeeName}</td>
                                        <td>{emp.employeeEmailId}</td>
                                        <td>{emp.mobileNo}</td>
                                        <td>{emp.dateJoined}</td>
                                        <td>{emp.department}</td>
                                        <td>{emp.availableLeave}</td>
                                    
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}
export default ListEmployee;




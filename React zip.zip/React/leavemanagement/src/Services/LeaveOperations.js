import axios from "axios";

const Leave_API_URL="http://localhost:34600/api/Leaves";

class LeaveOperations
{
    getLeave()
    {
        return axios.get(Leave_API_URL);
    }
    getLeaveById(leaveId)
    {
        return axios.get(Leave_API_URL+'/'+leaveId);
    }
    createLeave(leave)
    {
        return axios.post(Leave_API_URL,leave);
    }
    updateLeave(leave,leaveId)
    {
        return axios.put(Leave_API_URL+'/'+leaveId,leave);
    }
    deleteLeave(leaveId)
    {
        return axios.delete(Leave_API_URL+'/'+leaveId);
    }
}

export default new LeaveOperations();


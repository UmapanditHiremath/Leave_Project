import axios from "axios";
const Manager_API_URL="http://localhost:34600/api/Managers";

class ManagerOperations
{
    getEmployees()
    {
        return axios.get(Manager_API_URL);
    }
    getEmployeeById(employeeId)
    {
        return axios.get(Manager_API_URL+'/'+employeeId);
    }
    createEmployee(employee)
    {
        return axios.post(Manager_API_URL,employee);
    }
    updateEmployee(employee,employeeId)
    {
        return axios.put(Manager_API_URL+'/'+employeeId,employee);
    }
    deleteEmployee(employeeId)
    {
        return axios.delete(Manager_API_URL+'/'+employeeId);
    }
}

export default new ManagerOperations();
